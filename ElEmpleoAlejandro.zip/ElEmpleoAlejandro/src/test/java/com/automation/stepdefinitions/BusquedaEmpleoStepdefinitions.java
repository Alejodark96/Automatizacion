package com.automation.stepdefinitions;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;

import com.automation.steps.BusquedaEmpleoSteps;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import cucumber.api.java.es.Y;
import net.thucydides.core.annotations.Steps;

public class BusquedaEmpleoStepdefinitions {
	
	@Steps
	BusquedaEmpleoSteps stepsBusquedaEmpleo;
	
	@Dado("^que estoy en la pagina inicial de El Empleo$")
	public void queEstoyEnLaPaginaInicialDeElEmpleo() throws Exception{
		stepsBusquedaEmpleo.ingresarPagina();
	}

	@Cuando("^busco (.*) para cierta (.*)$")
	public void buscoContParaCiertaBogo(String cargo,String ciudad) throws Exception{
		stepsBusquedaEmpleo.buscarCargo(cargo, ciudad);
	}

	@Entonces("^se muestra la lista de empleos disponible$")
	public void seMuestraLaListaDeEmpleosDisponible() {
	    throw new PendingException();
	}

}
