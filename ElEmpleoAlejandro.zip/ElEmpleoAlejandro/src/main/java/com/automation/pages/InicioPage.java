package com.automation.pages;

import org.openqa.selenium.support.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.elempleo.com/co/")

public class InicioPage extends PageObject {
	
	@FindBy(xpath = "/html/body/div[4]/section[1]/div[3]/div[1]/div[2]/div/form/div/div/div/div[1]/div/span[1]/input[2]")
	WebElementFacade txtBusquedaCargo;
	
	@FindBy(xpath = "/html/body/div[4]/section[1]/div[3]/div[1]/div[2]/div/form/div/div/div/div[1]/div/span[1]/div/div/div[1]")
	WebElementFacade opcBusquedaCargo;
	
	@FindBy(xpath = "/html/body/div[4]/section[1]/div[3]/div[1]/div[2]/div/form/div/div/div/div[2]/div/span[1]/input[2]")
	WebElementFacade txtCiudadCargo;
	
	@FindBy(xpath = "/html/body/div[4]/section[1]/div[3]/div[1]/div[2]/div/form/div/div/div/div[2]/div/span[1]/div/div/div[1]")
	WebElementFacade opcCiudadCargo;
	
	
	public void buscarCargo(String cargo, String ciudad) {
		txtBusquedaCargo.sendKeys(cargo);
		opcBusquedaCargo.click();
		txtCiudadCargo.sendKeys(ciudad);
		opcCiudadCargo.click();
	}
	

}
