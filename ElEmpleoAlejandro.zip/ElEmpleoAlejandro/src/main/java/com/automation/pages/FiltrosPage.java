package com.automation.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;


import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;


@DefaultUrl("https://www.elempleo.com/co/ofertas-empleo/Bogot�?&trabajo=Contador")
public class FiltrosPage extends PageObject {
	
	@FindBy(xpath= "//*[@id=\"salary3\"]")
	WebElementFacade chkSalario;
	
	@FindBy(xpath = "//*[@id=\"publishDate2\"]")
	WebElementFacade radFechaPublicacion;
	
	@FindBy(xpath = "//*[@id=\"WorkAreaFilter1\"]")
	List<WebElementFacade> listaAreaTrabajo;
	
	public void seleccionOpciones() {
		
		chkSalario.click();
		esperar(6);
		radFechaPublicacion.click();
		esperar(6);
		
		for (int i = 0; i < listaAreaTrabajo.size(); i++) {
			if(listaAreaTrabajo.get(i).getText().equals("Administrativa y Financiera")) {
				listaAreaTrabajo.get(i).click();
			}
		}
		esperar(6);
	}
	
	
	public void esperar(int segundos) {
		try {
			Thread.sleep(segundos * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
