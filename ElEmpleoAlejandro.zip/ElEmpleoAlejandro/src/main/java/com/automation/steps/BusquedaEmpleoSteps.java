package com.automation.steps;

import java.util.List;
import java.util.Map;
import com.automation.pages.InicioPage;
import net.thucydides.core.annotations.Step;

public class BusquedaEmpleoSteps {
	
	InicioPage paginaInicio;
	
	@Step
	public void ingresarPagina() {
		paginaInicio.open();
	}
	
	@Step
	public void buscarCargo(String cargo, String ciudad) {
		paginaInicio.buscarCargo(cargo, ciudad);
	}

}
