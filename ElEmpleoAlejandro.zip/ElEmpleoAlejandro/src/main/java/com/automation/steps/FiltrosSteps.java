package com.automation.steps;

import java.util.List;
import java.util.Map;
import com.automation.pages.FiltrosPage;
import net.thucydides.core.annotations.Step;

public class FiltrosSteps {
	
	FiltrosPage paginaFiltros;
	
	@Step
	
	public void escogerFiltros() throws Exception{
		paginaFiltros.seleccionOpciones();
	}

}
